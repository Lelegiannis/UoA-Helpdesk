<?php

require_once(INCLUDE_DIR.'class.plugin.php');
require_once('config.php');

class SAMLSSPAuthPlugin extends Plugin {
    var $config_class = "SAMLSSPPluginConfig";

    function bootstrap() {
        $config = $this->getConfig();

        $samlModeConfig = $config->get('saml-ssp-mode');
        $clientSamlEnabled = in_array($samlModeConfig, array('client', 'all'));
        $staffSamlEnabled = in_array($samlModeConfig, array('staff', 'all'));

        if ($clientSamlEnabled) {
            require_once('saml.php');
            UserAuthenticationBackend::register(new SAMLSSPClientAuthBackend($this->getConfig()));
        }
        if ($staffSamlEnabled) {
            require_once('saml.php');
            StaffAuthenticationBackend::register(new SAMLSSPStaffAuthBackend($this->getConfig()));
        }
    }
}
