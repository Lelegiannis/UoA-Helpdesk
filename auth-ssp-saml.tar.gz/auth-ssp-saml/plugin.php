<?php

return array(
    'id' =>             'auth:ssp-saml', # notrans
    'version' =>        '1.0',
    'name' =>           'SAML Authentication for Clients and Staff based on simpleSAMLphp',
    'author' =>         'Sixto Pablo Martin Garcia',
    'description' =>    'Provides a configurable authentication backend for authenticating clients and staff using SAML. Compatible with OsTicket 10,11 and 12',
    'url' =>            'https://saml.info',
    'plugin' =>         'authentication.php:SAMLSSPAuthPlugin'
);
