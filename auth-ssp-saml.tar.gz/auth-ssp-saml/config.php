<?php

require_once(INCLUDE_DIR.'class.plugin.php');
include_once(INCLUDE_DIR.'class.dept.php');
include_once(INCLUDE_DIR.'class.role.php');
include_once(INCLUDE_DIR.'class.team.php');
include_once(INCLUDE_DIR.'class.organization.php');

class SAMLSSPPluginConfig extends PluginConfig {
    public function getOptions() {
        // Obtain list of departaments
        $departament_choices = array (0 => 'None');
        $availableDepts = Dept::getDepartments();
        $departament_choices = array_merge($departament_choices, $availableDepts);

        $role_choices = array (0 => 'None');
        $availableRoles = Role::getRoles();
        $role_choices = array_merge($role_choices, $availableRoles);

        $team_choices = array (0 => 'None');
        $availableTeams = Team::getTeams();
        $team_choices = array_merge($team_choices, $availableTeams);

        $org_choices = array (0 => 'None');
        $availableOrgs = array();
        foreach (Organization::objects() as $org) {
            $availableOrgs[$org->getName()] =  $org->getName();
        };
        $org_choices = array_merge($org_choices, $availableOrgs);

        return array(
            'saml-ssp-mode' => new ChoiceField(array(
                'label' => 'SAML Mode Support ',
                'hint' => "Specifies if SAML module is enabled for Clients/Agents.",
                'choices' => array(
                    'disabled' => 'Disabled',
                    'client' => 'Clients Only',
                    'staff' => 'Agents/Admins Only',
                    'all' => 'Agents/Admins and Clients',
                ),
                'configuration' => array('default' => 'disabled'),
            )),
            'saml-ssp-settings' => new SectionBreakField(array(
                'label' => 'SimpleSAMLphp settings',
                'hint' => "Set here info related to the simpleSAMLphp instance.",
            )),
            'saml-ssp-path' => new TextboxField(array(
                'label' => 'SimpleSAMLphp path',
                'hint' => 'Set here the system path to the simpleSAMLphp instance',
                'configuration' => array('size'=>80, 'length'=>180),
            )),
            'saml-ssp-client-authentication-source' => new TextboxField(array(
                'label' => 'Client Authentication Source',
                'hint' => 'Select the SP authentication source you want to use for Clients (Sources are in /config/authsources.php)',
                'configuration' => array('size'=>50, 'length'=>180),
            )),
            'saml-ssp-staff-authentication-source' => new TextboxField(array(
                'label' => 'Staff Authentication Source',
                'hint' => 'Select the SP authentication source you want to use for Staff (Sources are in /config/authsources.php)',
                'configuration' => array('size'=>50, 'length'=>180),
            )),
            'saml-ssp-discovery-service-url' => new TextboxField(array(
                'label' => 'Discovery Service URL',
                'hint' => 'If defined, OsTicket will use the discovery service to decide the IdP to be used',
                'configuration' => array('size'=>50, 'length'=>180),
            )),
            'saml-ssp-options-general' => new SectionBreakField(array(
                'label' => 'OPTIONS [GENERAL]',
                'hint' => "In this section the behavior of the plugin is set.",
            )),
            'saml-ssp-options-account_matcher' => new ChoiceField(array(
                'label' => 'Match OSTicket account by',
                'hint' => "Select what field will be used in order to find the user account. If you select the 'email' fieldname the plugin will prevent that the user can change his mail in his profile.",
                'choices' => array(
                    'username' => 'Username',
                    'mail' => 'E-mail',
                ),
                'configuration' => array('default' => 'username'),
            )),
            'saml-ssp-options-slo' => new BooleanField(array(
                'label' => 'Single Log Out',
                'hint' => 'Enable/disable Single Log Out. SLO is a complex functionality, the most common SLO implementation is based on front-channel (redirections), sometimes if the SLO workflow fails a user can be blocked in an unhandled view. If the admin does not controls the set of apps involved in the SLO process maybe is better to disable this functionality because can carry more problems than benefits.',
                'configuration' => array('default'=>false),
            )),
            'saml-ssp-options-username-clean' => new BooleanField(array(
                'label' => 'Username manipulation',
                'hint' => 'OsTicket requires username to match the regular expression [\p{L}\d._-]+ .If this flag is enabled, the extension will try to replace invalid chars from the username provided by the IdP with the char _',
                'configuration' => array('default'=>false),
            )),
            'saml-ssp-options-client' => new SectionBreakField(array(
                'label' => 'OPTIONS [CLIENTS]',
                'hint' => "In this section the behavior of the plugin is set.",
            )),
            'saml-ssp-options-autocreate' => new BooleanField(array(
                'label' => 'Create client if not exists',
                'hint' => 'Auto-provisioning. If a client does not exist, OSTicket will create a client account with the data provided by the IdP. Review the Mapping section.',
                'configuration' => array('default'=>false),
            )),
            'saml-ssp-options-updateuser' => new BooleanField(array(
                'label' => 'Update client data',
                'hint' => 'Auto-update. OSTicket will update the account of the user with the data provided by the IdP (client users, not staff). Review the Mapping section. It updates: name, phone, organization and mail if is not the matcher.',
                'configuration' => array('default'=>false),
            )),
            'saml-ssp-options-organization' => new ChoiceField(array(
                'label' => 'Default Organization',
                'hint' => "If autoprovision client account is enabled and the IdP does not provide any organization, assign that organization by default. (org name)",
                'choices' => $org_choices,
                'configuration' => array('default' => 0),
            )),
            'saml-ssp-options-staff' => new SectionBreakField(array(
                'label' => 'OPTIONS [STAFF]',
                'hint' => "In this section the behavior of the plugin is set.",
            )),
            'saml-ssp-options-autocreate-staff' => new BooleanField(array(
                'label' => 'Create agent/staff if not exists',
                'hint' => 'Auto-provisioning. If a agent/staff does not exist, OSTicket will create an agent/staff account with the data provided by the IdP. Review the Mapping section.',
                'configuration' => array('default'=>false),
            )),
            'saml-ssp-options-update-staff' => new BooleanField(array(
                'label' => 'Update staff data',
                'hint' => 'Auto-update. OSTicket will update the account of the staff user with the data provided by the IdP. Review the Mapping section.',
                'configuration' => array('default'=>false),
            )),
            'saml-ssp-options-system-role' => new ChoiceField(array(
                'label' => 'Default System Role',
                'hint' => "If autoprovision staff account is enabled and the IdP does not provide any system role, assign that system role by default. If None is set, then the account will not be created",
                'choices' => array(
                    'none' => 'None',
                    'agent' => 'Agent',
                    'admin' => 'Admin',
                ),
                'configuration' => array('default' => 'none'),
            )),
            'saml-ssp-options-primary-departament' => new ChoiceField(array(
                'label' => 'Default Primary Departament',
                'hint' => "If autoprovision staff account is enabled and the IdP does not provide any departament, assign that primary departament by default.",
                'choices' => $departament_choices,
                'configuration' => array('default' => 0),
            )),
            'saml-ssp-options-primary-role' => new ChoiceField(array(
                'label' => 'Default Primary Role',
                'hint' => "If autoprovision staff accounts is enabled and the IdP does not provide any primary role, assign that primary role by default.",
                'choices' => $role_choices,
                'configuration' => array('default' => 0),
            )),
            'saml-ssp-options-secondary-departament' => new ChoiceField(array(
                'label' => 'Default Secondary Departament',
                'hint' => "If autoprovision staff account is enabled and the IdP does not provide any departament, assign that secondary departament by default.",
                'choices' => $departament_choices,
                'configuration' => array('default' => 0),
            )),
            'saml-ssp-options-secondary-role' => new ChoiceField(array(
                'label' => 'Default Secondary Role',
                'hint' => 'If autoprovision staff account is enabled and the IdP does not provide any role, assign that secondary role by default.',
                'choices' => $role_choices,
                'configuration' => array('default' => 0),
            )),
            'saml-ssp-options-team' => new ChoiceField(array(
                'label' => "Default team",
                "hint" =>  'If autoprovision staff account is enabled and the IdP does not provide any team info, assign that team by default.',
                'choices' => $team_choices,
                'configuration' => array('default' => 0),
            )),
/*
            'saml-ssp-options-enable-alerts-on-dept' => new TextboxField(array(
                'label' => 'Extended Access alerts enabled',
                'hint' => 'List the ids of departaments of the extended access (comma separated) which alerts should be enabled when provisioning/upating the staff account',
                'configuration' => array('size'=>80, 'length'=>180),
            )),
*/
            'saml-ssp-options-enable-alerts-on-team' => new TextboxField(array(
                'label' => 'Team alerts enabled',
                'hint' => 'List the ids of teams (comma separated) which alerts should be enabled when provisioning/upating the staff account',
                'configuration' => array('size'=>80, 'length'=>180),
            )),
            'saml-ssp-attr-mapping' => new SectionBreakField(array(
                'label' => 'ATTRIBUTE MAPPING',
                'hint' => "Sometimes the names of the attributes sent by the IdP don't match the names used by OSTicket's accounts. In this section we can set the mapping between IdP fields and OSTicket fields. In case of Departament and Role fields, If the info is provided in 1 unique file as a multivalued or comma separated form, only assign the mapping for the primary field. The extension will assign dept/roles in strict order as received in the SAMLResponse, so primary and secundary will be added both, in strict order.",
            )),
            'saml-ssp-attr-mapping-username' => new TextboxField(array(
                'label' => 'Username',
                'configuration' => array('size'=>30, 'length'=>60),
            )),
            'saml-ssp-attr-mapping-mail' => new TextboxField(array(
                'label' => 'E-mail',
                'configuration' => array('size'=>30, 'length'=>60),
            )),
            'saml-ssp-attr-mapping-fullname' => new TextboxField(array(
                'label' => 'Fullname',
                'configuration' => array('size'=>30, 'length'=>60),
            )),
            'saml-ssp-attr-mapping-firstname' => new TextboxField(array(
                'label' => 'Firstname',
                'configuration' => array('size'=>30, 'length'=>60),
            )),
            'saml-ssp-attr-mapping-lastname' => new TextboxField(array(
                'label' => 'Lastname',
                'configuration' => array('size'=>30, 'length'=>60),
            )),
            'saml-ssp-attr-mapping-phone' => new TextboxField(array(
                'label' => 'Phone',
                'configuration' => array('size'=>30, 'length'=>60),
            )),
            'saml-ssp-attr-mapping-organization' => new TextboxField(array(
                'label' => 'Organization',
                'configuration' => array('size'=>30, 'length'=>60),
                'hint' => "Provide the name of the organization that should match Osticket Org name [Only for clients]",
            )),
            'saml-ssp-attr-mapping-teams' => new TextboxField(array(
                'label' => 'Teams',
                'hint' => "Attribute Name on the SAMLResponse providing team_id values  [Only for staff]",
                'configuration' => array('size'=>30, 'length'=>60),
            )),
            'saml-ssp-attr-mapping-system-role' => new TextboxField(array(
                'label' => 'System Role',
                'hint' => "Attribute Name on the SAMLResponse providing System Role info. Indicates if the user is or not an administrator. Possible values: admin | agent   [Only for staff]",
                'configuration' => array('size'=>30, 'length'=>60),
            )),
            'saml-ssp-attr-mapping-primary-departament' => new TextboxField(array(
                'label' => 'Primary Departament',
                'hint' => "Attribute Name on the SAMLResponse providing Primary Departament  info (dept_id).  [Only for staff]",
                'configuration' => array('size'=>30, 'length'=>60),
            )),
            'saml-ssp-attr-mapping-primary-role' => new TextboxField(array(
                'label' => 'Primary Role',
                'hint' => "Attribute Name on the SAMLResponse providing Primary Departament  info (role_id).  [Only for staff]",
                'configuration' => array('size'=>30, 'length'=>60),
            )),
            'saml-ssp-attr-mapping-secondary-departament' => new TextboxField(array(
                'label' => 'Secondary Departament',
                'hint' => "Attribute Name on the SAMLResponse providing Secundary Departament  info (dept_id)  [Only for staff]",
                'configuration' => array('size'=>30, 'length'=>60),
            )),
            'saml-ssp-attr-mapping-secondary-role' => new TextboxField(array(
                'label' => 'Secondary Role',
                'hint' => "Attribute Name on the SAMLResponse providing Secundary Role  info (role_id) [Only for staff]",
                'configuration' => array('size'=>30, 'length'=>60),
            )),
            'saml-ssp-customizations' => new SectionBreakField(array(
                'label' => 'CUSTOMIZATIONS',
                'hint' => "Handle what messages are showed in the login form.",
            )),
            'saml-ssp-customizations-client-login-text' => new TextboxField(array(
                'label' => 'Client SSO Login Text',
                'hint' => "The text of the link that initiates SAML SSO on the client login form, default value if not customization provided: 'SAML For Clients'",
                'configuration' => array('size'=>60, 'length'=>100),
            )),
            'saml-ssp-customizations-agent-login-text' => new TextboxField(array(
                'label' => 'Agent/Admin SSO Login Text',
                'hint' => "The text of the link that initiates SAML SSO on the Agent/Admin (SCP) login form, default value if not customization provided: 'SAML For Agent/Admin'",
                'configuration' => array('size'=>60, 'length'=>100),
            )),
        );
    }
}
