In order to activate the SAML support on OSTicket.

1. Move the 'auth-ssp-saml' folder at include/plugins

2. Log as admin at the SCP, access to the Admin Panel, Manage->Plugins->Add new Plugin  and Install and enable the SAML plugin.

3. At the Admin panel access to the SAML plugin and configure it

4. This extension uses simpleSAMLphp so be sure you have configured an SP instance on simpleSAMLphp and to connect it with the desired IdP(s).
